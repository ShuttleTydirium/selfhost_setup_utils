#depends: libstdc++
apk app libstdc++